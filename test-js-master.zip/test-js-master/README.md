## Make a collapse game level like -  https://apps.facebook.com/diamonddash
## using framework -   http://phaser.io/
## and resources in this repo

# Game should have basic mechanic implemented.
	* On icon click 3+ same nearest icons removed
	* New random icons generated
	* Game sounds (click, win, back)
	* Score calculation with multiplayer 1.3
		3 icons - 100 points
		4 icons - 130 points
		5 icons -  169 points
	* Basic game UI - Score and Combo labels

# What do we check :
	* Code quality 
	* Code efficiency
	* Animations and visual effects
	* Creativity

# You can add any other content or behaviour to make a cool game.